//
//  dummyLibrary.h
//  dummyLibrary
//
//  Created by Chanakya Mathi on 3/20/17.
//  Copyright © 2017 Chanakya Mathi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for dummyLibrary.
FOUNDATION_EXPORT double dummyLibraryVersionNumber;

//! Project version string for dummyLibrary.
FOUNDATION_EXPORT const unsigned char dummyLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <dummyLibrary/PublicHeader.h>


